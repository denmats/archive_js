# type_n_speak
author Brad Traversy
