def prime_number():
  prime_range = 100
  flag = 0

  for i in range(2,prime_range+1):
    if i == 2:
      print(2)
    for j in range(2,i):
      if i%j == 0:
        flag = flag + 1
    if flag < 1 and i != 2:
      print(i) 
    flag = 0   

prime_number()